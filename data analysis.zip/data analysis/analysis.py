import pandas as pd
import numpy as np
from datetime import datetime
import matplotlib.pyplot as plt
from sklearn.mixture import BayesianGaussianMixture

df1 = pd.read_csv('/Users/jia/Downloads/new data 1-19/result_test1.csv')
df2 = pd.read_csv('/Users/jia/Downloads/new data 1-19/result_test2.csv')
df3 = pd.read_csv('/Users/jia/Downloads/data1-26/result_test1.csv')
df4 = pd.read_csv('/Users/jia/Downloads/data1-26/result_test2.csv')
df5 = pd.read_csv('/Users/jia/Downloads/data1-26/result_test3.csv')
df3['ID_1'] = '261'+ df3['ID_1']
df4['ID_1'] = '262'+ df4['ID_1']
df5['ID_1'] = '263'+ df5['ID_1']

df = pd.concat([df1, df2, df3, df4, df5])
# plt.boxplot(df['depth_mm'])
df['timestamp'] = df['TimeNow'].apply(lambda x: datetime. strptime(x, '%Y-%m-%d %H:%M:%S.%f'))

# ====Merge ID====
# add neighbouring depth
df['next_ID'] = df['ID_1'].shift(-1)
df['next_depth'] = df['depth_mm'].shift(-1)
df['depth_sum'] = df.depth_mm + df.next_depth
df['time_dif'] = (df['timestamp'].shift(-1)-df['timestamp']).apply(lambda x: x.seconds)
# flag dif cameras
df['cam_flag'] = np.where(df.ID_1.str.strip().str[-2:] == df.next_ID.str.strip().str[-2:],0,1)
df['new_ID'] = np.where((df.depth_sum>=16000) & (df.depth_sum<18000) & (df.cam_flag ==1) & (df.time_dif<=1),'m_'+df.ID_1, df.ID_1)
merge_ID = df[df.new_ID.str.strip().str[0]=='m'][['ID_1','next_ID','new_ID']].drop_duplicates()
# df['final_ID'] = df['ID_1'].apply(lambda x: x.replace(x, df.)
# df['final_ID'] = df['ID_1'].replace(dict(zip(merge_ID.ID_1, merge_ID.new_ID)))
# df['final_ID1'] = df['final_ID'].replace(dict(zip(merge_ID.next_ID, merge_ID.new_ID)))

# build neighboring graph
import networkx as nx
G=nx.from_pandas_edgelist(merge_ID, 'ID_1', 'next_ID')
comp = list(nx.connected_components(G))
nx.draw_networkx(G, font_size = 8, node_size = 80, pos=nx.spring_layout(G))
# [len(c) for c in sorted(nx.connected_components(G), key=len, reverse=True)]

# replace IDs with new ID
d = {}
for i in range(len(comp)):
    for j in range(len(comp[i])):
        d[list(comp[i])[j]] = 'm_' + str(i)
    
df['final_ID'] = df['ID_1'].replace(d)
df['ID_1'] = df['final_ID']

# df1 = df[['ID_1','next_ID','depth_sum','cam_flag','new_ID']]
df = df[df.depth_mm <= 8000]
x = df.Position_x
# Scale measured depth to match real depth
d = df.depth_mm/4

# Project x pixel coordinate to x world coordinate, top view
# horizontal FoV 70, focal length 1.88mm
h_fov = 70
f = 1.88
f_p = 320/(np.tan((h_fov/ 2) * np.pi/ 180))

# conversion factor a, pixel to mm
a = f/f_p

x_mm = (x - 320) * a * (d + f)/f
# x_mm = a * x_p

# exclude outliers


df['x_adj'] = x_mm
df['dist_mm'] = np.sqrt(df.x_adj**2 + (2000-d)**2)
# plt.boxplot(df['depth_mm'])
##=====Analysis======##
# Duration
duration = df.groupby('ID_1')['timestamp'].agg(['min', 'max'])
duration['duration'] = duration['max'] - duration['min']
duration['duration_s'] = duration['duration'].apply(lambda x: x.seconds) # microseconds

# Distance
distance = df.groupby('ID_1')['dist_mm'].agg(['min', 'max','mean','median'])

# Join
result = duration.merge(distance, left_index=True, right_index=True, suffixes=('_timestamp', '_distance'))
result = result.iloc[:,3:8]
# result.drop(index='64_1', inplace=True)
result = result[result.duration_s!=0]
# Clustering
cluster_result = pd.DataFrame()

## Mean
bgm = BayesianGaussianMixture(n_components=3, random_state=42).fit(result[['mean', 'duration_s']])
centers = bgm.means_
result['cluster'] = bgm.predict(result[['mean', 'duration_s']])
cluster_result['mean'] = result['cluster'].replace({0:2})

fig = plt.figure()
plt.scatter(result['mean'], result.duration_s, c=result.cluster)
fig.suptitle('Mean_distance', fontsize=18)
plt.xlabel('distance(mm)', fontsize=10)
plt.ylabel('duration', fontsize=10)
fig.savefig('mean.jpg')
## Median
bgm = BayesianGaussianMixture(n_components=3, random_state=42).fit(result[['median', 'duration_s']])
centers = bgm.means_
result['cluster'] = bgm.predict(result[['median', 'duration_s']])
cluster_result['median'] = result['cluster']

fig = plt.figure()
plt.scatter(result['median'], result.duration_s, c=result.cluster)
fig.suptitle('Median_distance', fontsize=18)
plt.xlabel('distance(mm)', fontsize=10)
plt.ylabel('duration', fontsize=10)
fig.savefig('median.jpg')
## Min
bgm = BayesianGaussianMixture(n_components=3, random_state=42).fit(result[['min_distance', 'duration_s']])
centers = bgm.means_
result['cluster'] = bgm.predict(result[['min_distance', 'duration_s']])
cluster_result['min'] = result['cluster'].replace({0:2, 2:1, 1:0})

fig = plt.figure()
plt.scatter(result['min_distance'], result.duration_s, c=result.cluster)
fig.suptitle('Min_distance', fontsize=18)
plt.xlabel('distance(mm)', fontsize=10)
plt.ylabel('duration', fontsize=10)
fig.savefig('min.jpg')


#------kmeans
# from sklearn.cluster import KMeans
# kmeans = KMeans(n_clusters=3, random_state=42).fit(result[['median', 'duration_s']])
# result['cluster'] = bgm.predict(result[['median', 'duration_s']])
# plt.scatter(result['median'], result.duration_s, c=result.cluster)